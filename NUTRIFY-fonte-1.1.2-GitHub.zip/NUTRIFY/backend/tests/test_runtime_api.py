"""Regressões de configuração: não conectam ao MongoDB ou a serviços externos."""
import builtins
import importlib
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def runtime(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.setenv("MONGO_URL", "mongodb://localhost:27017")
    monkeypatch.setenv("DB_NAME", "nutrify_test")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    server = importlib.import_module("server")
    monkeypatch.setattr(server, "EMERGENT_LLM_KEY", "")
    server.app.dependency_overrides[server.get_current_user] = lambda: {"user_id": "runtime_test", "consents": {"ai_processing": {"accepted": True, "version": server.POLICY_VERSION}}}
    # Sem context manager: não executa o lifespan que cria índices no MongoDB.
    client = TestClient(server.app)
    yield server, client
    server.app.dependency_overrides.clear()
    client.close()


def test_health_without_database(runtime):
    _, client = runtime
    assert client.get("/health").json() == {"status": "ok"}


@pytest.mark.parametrize("path,body", [
    ("/api/ai/recognize", {"image_base64": "abc"}),
    ("/api/ai/meal-suggestions", {"meal": "jantar"}),
    ("/api/chat/stream", {"message": "Olá"}),
])
def test_missing_ai_key_returns_503(runtime, path, body):
    _, client = runtime
    response = client.post(path, json=body)
    assert response.status_code == 503
    assert "IA" in response.json()["detail"]


def test_missing_private_sdk_returns_503(runtime, monkeypatch):
    server, client = runtime
    monkeypatch.setattr(server, "EMERGENT_LLM_KEY", "test-only")
    original_import = builtins.__import__

    def without_sdk(name, *args, **kwargs):
        if name.startswith("emergentintegrations"):
            raise ModuleNotFoundError(name)
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", without_sdk)
    response = client.post("/api/chat/stream", json={"message": "Olá"})
    assert response.status_code == 503


def test_protected_route_rejects_missing_token(runtime):
    server, client = runtime
    server.app.dependency_overrides.clear()
    assert client.get("/api/profile").status_code == 401


def test_missing_consent_precedes_ai_configuration(runtime):
    server, client = runtime
    server.app.dependency_overrides[server.get_current_user] = lambda: {"user_id": "runtime_test"}
    assert client.post("/api/chat/stream", json={"message": "Olá"}).status_code == 403
