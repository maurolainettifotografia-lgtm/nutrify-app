"""Testes de privacidade (LGPD): consentimento de IA, exportacao de dados e idade minima.
Precisam do backend rodando com o banco de TESTE (veja seed_test.py)."""
import os
from datetime import date
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2] / "frontend" / ".env")
API = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/") + "/api"
H = {"Authorization": "Bearer test-token-nutrify-123", "Content-Type": "application/json"}


def test_exige_login():
    assert requests.get(f"{API}/account/consent").status_code == 401
    assert requests.get(f"{API}/account/export").status_code == 401


def test_consentimento_de_ia_liga_e_desliga_o_recurso():
    try:
        off = requests.put(f"{API}/account/consent", headers=H, json={"ai_processing": False})
        assert off.status_code == 200 and off.json()["ai_processing"] is False
        # sem consentimento, os recursos de IA sao bloqueados no servidor
        r = requests.post(f"{API}/ai/meal-suggestions", headers=H, json={"meal": "almoco"})
        assert r.status_code == 403
        r = requests.post(f"{API}/chat/stream", headers=H, json={"message": "oi"})
        assert r.status_code == 403
        on = requests.put(f"{API}/account/consent", headers=H, json={"ai_processing": True})
        assert on.json()["ai_processing"] is True
        assert requests.get(f"{API}/account/consent", headers=H).json()["ai_processing"] is True
    finally:
        requests.put(f"{API}/account/consent", headers=H, json={"ai_processing": True})


def test_exportar_dados_traz_tudo_sem_ids_internos():
    r = requests.get(f"{API}/account/export", headers=H)
    assert r.status_code == 200
    d = r.json()
    assert {"account", "profiles", "diary", "weights", "routines", "workout_sessions", "chat_messages"} <= set(d)
    assert "email" in d["account"] and "exported_at" in d
    assert "user_id" not in str(d["profiles"]) and "_id" not in str(d["diary"])


def test_menor_de_18_anos_e_recusado():
    t = date.today()
    seventeen = f"{t.year - 17}-{t.month:02d}-{min(t.day, 28):02d}"
    r = requests.put(f"{API}/profile", headers=H, json={"birth_date": seventeen})
    assert r.status_code == 422
