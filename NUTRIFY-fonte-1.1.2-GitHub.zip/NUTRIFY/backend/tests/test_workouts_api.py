"""Testes do montador de treinos (/api/exercises, /api/routines, /api/sessions).
Precisam do backend rodando com o banco de TESTE (veja seed_test.py)."""
import os
import requests
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2] / "frontend" / ".env")
BASE_URL = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/")
H = {"Authorization": "Bearer test-token-nutrify-123", "Content-Type": "application/json"}
H_OTHER = {"Authorization": "Bearer test-token-new-456", "Content-Type": "application/json"}
API = f"{BASE_URL}/api"


def _routine(name="TEST_Treino A", n=2):
    ex = [
        {"name": "Supino reto com barra", "muscle_group": "peito", "sets": 4, "reps": 8, "weight_kg": 60, "rest_s": 90},
        {"name": "Tríceps testa", "muscle_group": "triceps", "sets": 3, "reps": 12, "weight_kg": 20, "rest_s": 60},
    ]
    return {"name": name, "notes": "Foco em carga", "exercises": ex[:n]}


def test_exige_login():
    assert requests.get(f"{API}/routines").status_code == 401
    assert requests.get(f"{API}/exercises").status_code == 401


def test_biblioteca_de_exercicios():
    r = requests.get(f"{API}/exercises", headers=H, params={"q": "supino", "group": "peito"})
    assert r.status_code == 200
    d = r.json()
    assert len(d["groups"]) == 10 and d["results"] and all(e["group"] == "peito" for e in d["results"])


def test_crud_de_treino_e_validacoes():
    c = requests.post(f"{API}/routines", headers=H, json=_routine())
    assert c.status_code == 200, c.text
    rid = c.json()["id"]
    assert c.json()["exercise_count"] == 2

    assert any(x["id"] == rid for x in requests.get(f"{API}/routines", headers=H).json()["results"])
    assert requests.get(f"{API}/routines/{rid}", headers=H).json()["name"] == "TEST_Treino A"

    # outro usuario nao enxerga nem altera
    assert requests.get(f"{API}/routines/{rid}", headers=H_OTHER).status_code == 404
    assert requests.put(f"{API}/routines/{rid}", headers=H_OTHER, json=_routine()).status_code == 404

    up = requests.put(f"{API}/routines/{rid}", headers=H, json=_routine("TEST_Treino A2", n=1))
    assert up.status_code == 200 and up.json()["exercise_count"] == 1

    # validacoes
    assert requests.post(f"{API}/routines", headers=H, json={**_routine(), "exercises": []}).status_code == 400
    bad = _routine(); bad["exercises"][0]["weight_kg"] = -5
    assert requests.post(f"{API}/routines", headers=H, json=bad).status_code == 422
    bad = _routine(); bad["exercises"][0]["sets"] = 0
    assert requests.post(f"{API}/routines", headers=H, json=bad).status_code == 422
    assert requests.post(f"{API}/routines", headers=H, json={**_routine(), "name": "   "}).status_code == 422

    assert requests.delete(f"{API}/routines/{rid}", headers=H).status_code == 200
    assert requests.get(f"{API}/routines/{rid}", headers=H).status_code == 404


def test_sessao_historico_e_ultima_carga():
    rid = requests.post(f"{API}/routines", headers=H, json=_routine("TEST_Treino B")).json()["id"]
    body = {
        "routine_id": rid, "routine_name": "TEST_Treino B", "duration_min": 55,
        "exercises": [
            {"name": "Supino reto com barra", "muscle_group": "peito", "sets": [
                {"reps": 10, "weight_kg": 60, "done": True},
                {"reps": 8, "weight_kg": 65, "done": True},
                {"reps": 5, "weight_kg": 100, "done": False},
            ]},
            {"name": "Tríceps testa", "muscle_group": "triceps", "sets": [{"reps": 12, "weight_kg": 20, "done": False}]},
        ],
    }
    s = requests.post(f"{API}/sessions", headers=H, json=body)
    assert s.status_code == 200, s.text
    d = s.json()
    assert d["total_sets"] == 2 and d["volume_kg"] == 1120.0   # 10x60 + 8x65; a serie nao feita nao conta
    assert len(d["exercises"]) == 1                              # exercicio sem serie feita nao e guardado

    last = requests.get(f"{API}/routines/{rid}/last", headers=H).json()["last"]
    assert last["supino reto com barra"]["sets"][1] == {"reps": 8, "weight_kg": 65}
    assert "triceps testa" not in last

    rows = requests.get(f"{API}/routines", headers=H).json()["results"]
    assert next(r for r in rows if r["id"] == rid)["last_done"] == d["date"]
    assert any(x["id"] == d["id"] for x in requests.get(f"{API}/sessions", headers=H).json()["results"])

    # validacoes
    none_done = {**body, "exercises": [{"name": "Stiff", "sets": [{"reps": 8, "weight_kg": 50, "done": False}]}]}
    assert requests.post(f"{API}/sessions", headers=H, json=none_done).status_code == 400
    assert requests.post(f"{API}/sessions", headers=H, json={**body, "date": "2099-01-01"}).status_code == 400
    neg = {**body, "exercises": [{"name": "Stiff", "sets": [{"reps": -1, "weight_kg": 50}]}]}
    assert requests.post(f"{API}/sessions", headers=H, json=neg).status_code == 422

    assert requests.delete(f"{API}/sessions/{d['id']}", headers=H).status_code == 200
    assert not any(x["id"] == d["id"] for x in requests.get(f"{API}/sessions", headers=H).json()["results"])
    requests.delete(f"{API}/routines/{rid}", headers=H)


def test_calorias_no_diario_recordes_e_evolucao():
    from datetime import date as _d
    today = _d.today().isoformat()
    ex = "TEST_Exercício de recorde"

    def body(weight, log=True):
        return {"routine_name": "TEST_Treino C", "duration_min": 60, "log_calories": log,
                "exercises": [{"name": ex, "muscle_group": "peito", "sets": [{"reps": 8, "weight_kg": weight, "done": True}]}]}

    # 1o treino: sem historico, entao nao ha recorde; o gasto calorico entra no diario
    s1 = requests.post(f"{API}/sessions", headers=H, json=body(60)).json()
    assert s1["records"] == [] and s1["calories_burned"] > 0 and s1["workout_id"]
    day = requests.get(f"{API}/workouts", headers=H, params={"date": today}).json()["results"]
    w = next(x for x in day if x["id"] == s1["workout_id"])
    assert w["type"] == "musculacao" and w["calories"] == s1["calories_burned"] and w["title"] == "TEST_Treino C"

    # 2o treino com carga maior: recorde de carga; sem somar calorias quando o usuario desliga
    s2 = requests.post(f"{API}/sessions", headers=H, json=body(65, log=False)).json()
    assert s2["calories_burned"] == 0 and s2["workout_id"] is None
    assert [(r["kind"], r["value"], r["previous"]) for r in s2["records"]] == [("carga", 65.0, 60.0)]

    # evolucao
    names = [e["name"] for e in requests.get(f"{API}/progress/exercises", headers=H).json()["results"]]
    assert ex in names
    prog = requests.get(f"{API}/progress/exercise", headers=H, params={"name": ex}).json()
    assert len(prog["points"]) == 2 and prog["records"]["max_weight"]["value"] == 65.0
    assert requests.get(f"{API}/progress/exercise", headers=H, params={"name": ""}).status_code == 422

    # apagar o treino tira tambem o gasto calorico do diario
    assert requests.delete(f"{API}/sessions/{s1['id']}", headers=H).status_code == 200
    day = requests.get(f"{API}/workouts", headers=H, params={"date": today}).json()["results"]
    assert not any(x["id"] == s1["workout_id"] for x in day)
    requests.delete(f"{API}/sessions/{s2['id']}", headers=H)
