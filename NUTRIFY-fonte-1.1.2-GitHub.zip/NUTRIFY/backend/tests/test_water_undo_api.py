"""Teste do desfazer da agua (/api/water). Precisa do backend rodando com o banco de TESTE."""
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2] / "frontend" / ".env")
API = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/") + "/api"
H = {"Authorization": "Bearer test-token-nutrify-123", "Content-Type": "application/json"}
DAY = "2026-01-02"  # dia isolado para nao misturar com outros testes


def _post(ml):
    return requests.post(f"{API}/water", headers=H, json={"date": DAY, "amount_ml": ml})


def _total():
    return requests.get(f"{API}/water", headers=H, params={"date": DAY}).json()["total_ml"]


def test_desfazer_agua_nunca_passa_de_zero():
    _post(-3000)  # zera o dia
    assert _total() == 0
    assert _post(500).json()["total_ml"] == 500
    assert _post(-200).json()["total_ml"] == 300
    assert _post(-3000).json()["total_ml"] == 0       # desfazer demais para em zero, nunca fica negativo
    assert _total() == 0


def test_quantidade_invalida_e_recusada():
    assert _post(0).status_code == 422
    assert _post(3001).status_code == 422
    assert _post(-3001).status_code == 422
