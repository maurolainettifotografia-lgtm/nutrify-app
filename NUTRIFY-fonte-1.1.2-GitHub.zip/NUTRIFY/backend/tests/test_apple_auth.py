"""Testes offline do Entrar com Apple: geram chaves proprias, sem falar com a Apple."""
import json
import sys
import time
from pathlib import Path

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    import httpx  # noqa: F401
except ModuleNotFoundError:  # estes testes nao usam rede; permite rodar sem o httpx instalado
    import types
    sys.modules["httpx"] = types.ModuleType("httpx")
import apple_auth as A  # noqa: E402

AUD = ["com.maurolainetti.nutrify"]
_RSA = rsa.generate_private_key(public_exponent=65537, key_size=2048)
_JWK = json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(_RSA.public_key()))
_JWK.update({"kid": "KEY1", "alg": "RS256", "use": "sig"})
JWKS = {"keys": [_JWK]}
_PEM = _RSA.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())


def _token(**over):
    now = int(time.time())
    claims = {"iss": A.APPLE_ISSUER, "aud": AUD[0], "sub": "001234.abcd", "iat": now, "exp": now + 600,
              "email": "pessoa@exemplo.com", "email_verified": "true"}
    claims.update(over)
    return jwt.encode({k: v for k, v in claims.items() if v is not None}, _PEM, algorithm="RS256", headers={"kid": "KEY1"})


def _rejected(token, jwks=JWKS):
    try:
        A.verify_identity_token(token, jwks, AUD)
    except A.AppleAuthError:
        return True
    return False


def test_token_valido_e_aceito():
    c = A.verify_identity_token(_token(), JWKS, AUD)
    assert c["sub"] == "001234.abcd" and c["email"] == "pessoa@exemplo.com"


def test_token_invalido_e_recusado():
    assert _rejected(_token(aud="com.outro.app"))                       # feito para outro app
    assert _rejected(_token(iss="https://evil.example.com"))            # emissor falso
    assert _rejected(_token(exp=int(time.time()) - 10))                 # vencido
    assert _rejected(_token(sub=None))                                  # sem sub
    assert _rejected(_token(), {"keys": []})                            # chave desconhecida
    # assinado por OUTRA chave RSA, mesmo com o kid certo
    other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    forged = jwt.encode({"iss": A.APPLE_ISSUER, "aud": AUD[0], "sub": "x", "iat": int(time.time()), "exp": int(time.time()) + 600},
                        other, algorithm="RS256", headers={"kid": "KEY1"})
    assert _rejected(forged)
    assert _rejected("isto.nao.e.um.jwt")


def test_ataque_de_troca_de_algoritmo_e_barrado():
    # HS256 usando o texto da chave publica como segredo: nao pode ser aceito
    public_pem = _RSA.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    now = int(time.time())
    claims = {"iss": A.APPLE_ISSUER, "aud": AUD[0], "sub": "x", "iat": now, "exp": now + 600}
    import hmac, hashlib, base64
    def b64(b): return base64.urlsafe_b64encode(b).rstrip(b"=")
    head = b64(json.dumps({"alg": "HS256", "typ": "JWT", "kid": "KEY1"}).encode())
    body = b64(json.dumps(claims).encode())
    sig = b64(hmac.new(public_pem, head + b"." + body, hashlib.sha256).digest())
    assert _rejected((head + b"." + body + b"." + sig).decode())


def test_segredo_do_cliente_para_a_apple():
    ec_key = ec.generate_private_key(ec.SECP256R1())
    pem = ec_key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
    secret = A.make_client_secret("TEAM123456", "KEYID12345", AUD[0], pem.replace("\n", "\\n"), now=1_700_000_000)  # aceita \n escapado
    head = jwt.get_unverified_header(secret)
    assert head["alg"] == "ES256" and head["kid"] == "KEYID12345"
    claims = jwt.decode(secret, ec_key.public_key(), algorithms=["ES256"], audience=A.APPLE_ISSUER,
                        options={"verify_exp": False, "verify_iat": False})
    assert claims["iss"] == "TEAM123456" and claims["sub"] == AUD[0] and claims["exp"] == 1_700_000_300


def test_client_ids_do_ambiente():
    import os
    os.environ.pop("APPLE_CLIENT_ID", None)
    assert A.client_ids() == ["com.maurolainetti.nutrify"]
    os.environ["APPLE_CLIENT_ID"] = "com.a.b, host.exp.Exponent"
    try:
        assert A.client_ids() == ["com.a.b", "host.exp.Exponent"]
    finally:
        os.environ.pop("APPLE_CLIENT_ID", None)
