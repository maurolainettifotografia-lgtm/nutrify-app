"""Fluxo de conta local com API e banco de testes reais."""
import uuid
import requests


def test_local_account_lifecycle(base_url):
    email=f'local-{uuid.uuid4().hex}@example.com'
    body={'email':email,'password':'Uma frase longa para teste','name':'Conta de teste'}
    token=None
    try:
        response=requests.post(f'{base_url}/api/auth/register',json=body)
        assert response.status_code==200,response.text
        token=response.json()['session_token']
        assert response.json()['user']['onboarded'] is False
        assert 'password' not in response.text
        assert requests.post(f'{base_url}/api/auth/register',json=body).status_code==409
        assert requests.post(f'{base_url}/api/auth/login',json={**body,'password':'incorreta'}).status_code==401
        login=requests.post(f'{base_url}/api/auth/login',json={**body,'email':email.upper()})
        assert login.status_code==200,login.text
        token=login.json()['session_token']
        headers={'Authorization':f'Bearer {token}'}
        assert requests.get(f'{base_url}/api/auth/me',headers=headers).json()['email']==email
        export=requests.get(f'{base_url}/api/account/export',headers=headers)
        assert 'password_hash' not in export.text
        assert requests.post(f'{base_url}/api/auth/logout',headers=headers).status_code==200
        assert requests.get(f'{base_url}/api/auth/me',headers=headers).status_code==401
        token=requests.post(f'{base_url}/api/auth/login',json=body).json()['session_token']
    finally:
        if token:
            headers={'Authorization':f'Bearer {token}'}
            assert requests.delete(f'{base_url}/api/account',headers=headers).status_code==200
            assert requests.get(f'{base_url}/api/auth/me',headers=headers).status_code==401


def test_login_attempt_limit(base_url):
    email=f'rate-{uuid.uuid4().hex}@example.com'
    body={'email':email,'password':'incorreta'}
    for _ in range(20):
        assert requests.post(f'{base_url}/api/auth/login',json=body).status_code==401
    response=requests.post(f'{base_url}/api/auth/login',json=body)
    assert response.status_code==429
    assert response.headers.get('Retry-After')=='900'
