"""Regressões offline do transporte da IA; nenhuma chave real é usada."""
import asyncio
import json
import sys
from pathlib import Path
import httpx
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import ai_direct as ai


@pytest.fixture
def transport(monkeypatch):
    monkeypatch.setenv('OPENAI_MODEL', 'test-model')
    original = httpx.AsyncClient
    seen=[]
    def handler(request):
        body=json.loads(request.content)
        seen.append(body)
        assert request.headers['authorization']=='Bearer test-only'
        if body['stream']:
            return httpx.Response(200, text='data: {"choices":[{"delta":{"content":"Olá"}}]}\n\ndata: [DONE]\n\n')
        return httpx.Response(200,json={'choices':[{'message':{'content':'{"foods":[]}'}}]})
    monkeypatch.setattr(ai.httpx,'AsyncClient',lambda **kwargs: original(transport=httpx.MockTransport(handler),**kwargs))
    return seen


def test_text_and_history(transport):
    chat=ai.LlmChat('test-only','test','system',initial_messages=[{'role':'system','content':'system'},{'role':'user','content':'previous'}])
    assert asyncio.run(chat.send_message(ai.UserMessage('hello'))) == '{"foods":[]}'
    assert len(transport[0]['messages'])==3
    assert transport[0]['store'] is False


def test_image_payload(transport):
    chat=ai.LlmChat('test-only','test','system')
    asyncio.run(chat.send_message(ai.UserMessage('foto',[ai.ImageContent('iVBORtest')])))
    content=transport[0]['messages'][-1]['content']
    assert content[1]['image_url']['url']=='data:image/png;base64,iVBORtest'


def test_stream(transport):
    async def collect():
        return [event async for event in ai.LlmChat('test-only','test','system').stream_message(ai.UserMessage('hello'))]
    events=asyncio.run(collect())
    assert events==[ai.TextDelta('Olá'),ai.StreamDone()]
