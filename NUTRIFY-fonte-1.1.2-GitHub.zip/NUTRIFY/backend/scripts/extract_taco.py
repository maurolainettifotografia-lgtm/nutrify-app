"""Extrai a TACO (4a edicao ampliada e revisada, NEPA/UNICAMP, 2011) do PDF oficial
para backend/taco_data.json.

Uso (precisa do pdftotext, do pacote poppler-utils):
    python scripts/extract_taco.py caminho/para/taco_4_edicao_ampliada_e_revisada.pdf

So e preciso rodar de novo se quiser regenerar o JSON. O app usa apenas o JSON.
Valores por 100 g de parte comestivel. "Tr" (traco) e "NA" (nao analisado) viram 0.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

NUM = r"(?:NA|Tr|\*|\d+(?:,\d+)?)"
ROW = re.compile(
    rf"^\s*(\d{{1,3}})\s+([A-Za-zÀ-ÿ][^\d]*?(?:[A-Za-zÀ-ÿ\)\d][^\n]*?)?)\s{{2,}}((?:{NUM}\s+){{5,}}{NUM})\s*$"
)
MINERAL_ROW = re.compile(rf"^\s*(\d{{1,3}})\s+((?:{NUM}\s+){{4,}}{NUM})\s*$")


def page_text(pdf: str, p: int) -> str:
    return subprocess.run(["pdftotext", "-layout", "-f", str(p), "-l", str(p), pdf, "-"],
                          capture_output=True, text=True, check=True).stdout


def val(tok: str):
    """'12,5' -> 12.5 ; 'Tr'/'NA'/'*' -> 0.0"""
    try:
        return float(tok.replace(",", "."))
    except ValueError:
        return 0.0


def unit_ends(text: str):
    """Posicao (coluna de texto) do fim de cada unidade '(g)', '(mg)'... da linha de cabecalho."""
    hdr = next(l for l in text.splitlines() if "(mg)" in l or "(kcal)" in l)
    return [m.end() for m in re.finditer(r"\([^)]*\)", hdr)]


def by_column(line: str, start: int, ends):
    """Atribui cada numero da linha a coluna cujo cabecalho termina mais perto dele.
    Assim, celulas vazias nao deslocam os valores para a coluna errada."""
    cols = {}
    for m in re.finditer(r"\S+", line[start:]):
        end = m.end() + start
        k = min(range(len(ends)), key=lambda i: abs(ends[i] - end))
        if abs(ends[k] - end) <= 6:
            cols[k] = m.group()
    return cols


def main(pdf: str, out: str):
    foods, sodium = {}, {}
    category = None  # a categoria vale ate aparecer a proxima (continua entre paginas)
    for p in range(29, 69):  # Tabela 1: paginas alternadas (nomes+macros / minerais+vitaminas)
        t = page_text(pdf, p)
        if "Descrição dos alimentos" in t:
            ends = unit_ends(t)  # umidade, kcal, kJ, prot, lip, colest, carb, fibra, cinzas, Ca, Mg
            started = False
            for line in t.splitlines():
                if "Descrição dos alimentos" in line:
                    started = True
                    continue
                if not started:
                    continue
                m = ROW.match(line)
                if m:
                    c = by_column(line, m.start(3), ends)
                    g = lambda k: val(c.get(k, "NA"))  # noqa: E731
                    foods[int(m.group(1))] = {
                        "id": int(m.group(1)),
                        # tira o numero de nota de rodape colado no fim ("Cerveja, pilsen 2")
                        "name": re.sub(r"\s+\d$", "", re.sub(r"\s+", " ", m.group(2)).strip()),
                        "category": category,
                        "calories": g(1),
                        "protein": g(3),
                        "fat": g(4),
                        "carbs": g(6),
                        "fiber": g(7),
                    }
                else:
                    s = line.strip()
                    if s and not s.isdigit() and len(s) < 70 and not s[0].isdigit() and ":" not in s:
                        category = s
        else:
            ends = unit_ends(t)  # Mn, P, Fe, Na, K, Cu, Zn, ... (todas em mg/ug)
            for line in t.splitlines():
                m = MINERAL_ROW.match(line)
                if m:
                    c = by_column(line, m.start(2), ends)
                    sodium[int(m.group(1))] = val(c.get(3, "NA"))  # 4a coluna = Sodio (mg)
    for i, f in foods.items():
        f["sodium"] = sodium.get(i, 0.0)
    data = [foods[i] for i in sorted(foods)]
    Path(out).write_text(json.dumps(data, ensure_ascii=False, indent=0), encoding="utf-8")
    print(f"{len(data)} alimentos gravados em {out}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1], str(Path(__file__).resolve().parents[1] / "taco_data.json"))
