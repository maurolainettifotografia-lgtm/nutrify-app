import os
from datetime import datetime, timezone, timedelta
from pymongo import MongoClient
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).parent / ".env")
# TRAVA DE SEGURANCA: este script cria usuarios com tokens FIXOS e conhecidos (estao no
# repositorio). Se rodasse no banco real, qualquer pessoa entraria nessas contas.
# So roda se ALLOW_TEST_SEED=1 e o nome do banco terminar em "_test" (ex.: DB_NAME=nutrify_test).
if os.environ.get("ALLOW_TEST_SEED") != "1" or not os.environ.get("DB_NAME", "").endswith("_test"):
    raise SystemExit("RECUSADO: use um banco de teste. Ex.: ALLOW_TEST_SEED=1 DB_NAME=nutrify_test python seed_test.py")

client = MongoClient(os.environ["MONGO_URL"])
db = client[os.environ["DB_NAME"]]

USER_ID = "user_testnutrify1"
EMAIL = "teste.nutrify@example.com"
TOKEN = "test-token-nutrify-123"

db.users.update_one(
    {"user_id": USER_ID},
    {"$set": {
        "user_id": USER_ID,
        "email": EMAIL,
        "name": "Usuário Teste",
        "picture": None,
        "consents": {"ai_processing": {"accepted": True, "version": "2026-10", "at": datetime.now(timezone.utc)}},
        "created_at": datetime.now(timezone.utc),
        "deleted_at": None,
    }},
    upsert=True,
)

db.user_sessions.update_one(
    {"session_token": TOKEN},
    {"$set": {
        "session_token": TOKEN,
        "user_id": USER_ID,
        "created_at": datetime.now(timezone.utc),
        "expires_at": datetime.now(timezone.utc) + timedelta(days=7),
    }},
    upsert=True,
)

db.profiles.update_one(
    {"user_id": USER_ID},
    {"$set": {
        "user_id": USER_ID,
        "onboarded": True,
        "name": "Usuário Teste",
        "sex": "male",
        "birth_date": "1995-05-20",
        "height_cm": 178,
        "weight_kg": 80,
        "goal_weight_kg": 75,
        "activity_level": "moderate",
        "goal": "emagrecimento",
        "athlete_mode": False,
        "updated_at": datetime.now(timezone.utc),
    }},
    upsert=True,
)

print("Seeded test user, session token:", TOKEN)

# Non-onboarded user (to test onboarding / birth date). Profile is removed on each run.
NEW_ID, NEW_TOKEN = "user_testnew1", "test-token-new-456"
db.users.update_one(
    {"user_id": NEW_ID},
    {"$set": {"user_id": NEW_ID, "email": "novo.nutrify@example.com", "name": "Novo Usuário",
              "picture": None, "created_at": datetime.now(timezone.utc), "deleted_at": None}},
    upsert=True,
)
db.user_sessions.update_one(
    {"session_token": NEW_TOKEN},
    {"$set": {"session_token": NEW_TOKEN, "user_id": NEW_ID, "created_at": datetime.now(timezone.utc),
              "expires_at": datetime.now(timezone.utc) + timedelta(days=7)}},
    upsert=True,
)
db.profiles.delete_one({"user_id": NEW_ID})
db.weights.delete_many({"user_id": NEW_ID})
print("Seeded non-onboarded user, session token:", NEW_TOKEN)
