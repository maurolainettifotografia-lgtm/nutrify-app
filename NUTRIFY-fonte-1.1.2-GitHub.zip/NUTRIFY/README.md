# Nutrify

Aplicativo React Native/Expo para alimentação, água, peso, receitas e treinos, com backend FastAPI e MongoDB. A versão atual pode rodar fora da plataforma Emergent.

## O que já funciona sem contas externas

Cadastro e login por e-mail/senha, perfil e metas, diário alimentar com tabela TACO, água, peso, receitas, favoritos, treinos, relatórios, exportação e exclusão de conta. A busca de produtos embalados usa o serviço público Open Food Facts. Google, Apple e IA são opcionais.

## Rodar no Windows

Pré-requisitos: Node.js 22.18+ com npm, Python 3.12 e MongoDB Community local ou Atlas.

Terminal 1, na pasta do projeto:
```powershell
cd backend
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
# Edite MONGO_URL e DB_NAME no backend/.env.
.\.venv\Scripts\python.exe -m uvicorn server:app --host 0.0.0.0 --port 8000 --reload
```

Terminal 2:
```powershell
cd frontend
Copy-Item .env.example .env
npm ci
npm run web
```

No navegador, crie sua conta e complete o perfil. Senhas de cadastro têm entre 15 e 128 caracteres; frases longas são aceitas. Os registros são persistidos no MongoDB, não em arquivos do frontend.

Para celular físico, ajuste EXPO_PUBLIC_BACKEND_URL para o IP da máquina (ex.: http://192.168.1.10:8000), use a mesma rede e libere a porta no firewall. Em emulador Android padrão, use http://10.0.2.2:8000. Rode `npm start` e use um cliente compatível com Expo SDK 57. Depois de mudar o .env, reinicie com `npx expo start --clear`.

## Rodar com Docker Compose

Esta configuração está preparada, mas não foi executada nesta máquina, que não possui Docker.

```powershell
Copy-Item .env.example .env
# Gere uma senha aleatória hexadecimal de 64 caracteres:
py -3.12 -c "import secrets; print(secrets.token_hex(32))"
# Cole a senha em MONGO_ROOT_PASSWORD no .env da raiz.
docker compose up --build -d
```

Abra http://localhost:8080. O MongoDB não expõe porta no host. O Nginx encaminha /api ao backend, então o frontend web funciona na mesma origem. A senha do MongoDB deve ser hexadecimal para evitar caracteres reservados na URL.

O volume `nutrify-data` preserva os dados. Para parar mantendo os dados, use `docker compose down`. Para publicar, configure domínio, HTTPS e APP_ORIGIN. O acesso por padrão está limitado à própria máquina. Faça backup do volume e não use o seed de testes no banco real.

## IA direta, sem Emergent

No backend/.env, preencha OPENAI_API_KEY e OPENAI_MODEL. Escolha um modelo disponível na sua conta que aceite Chat Completions, texto e imagens. A aplicação envia fotos, sugestões e mensagens diretamente à API da OpenAI, com consentimento e quota por usuário. Não há custo de IA durante as verificações locais: os testes de transporte usam respostas simuladas.

Nunca coloque uma chave de IA em variável EXPO_PUBLIC_, no frontend ou no Git. Sem uma chave configurada, a IA responde indisponível e o restante do app funciona. A chave e os créditos da sua conta são necessários para a validação real.

O código legado Emergent permanece opcional: EMERGENT_LLM_KEY e o SDK do requirements-ai.txt exigem a fonte oficial da plataforma. A configuração direta OpenAI tem prioridade se ambas estiverem preenchidas.

Documentação utilizada: https://developers.openai.com/api/reference/resources/chat e https://developers.openai.com/api/docs/guides/images-vision?api-mode=chat.

## Login Google e Apple (opcionais)

O login padrão é e-mail/senha. Para Google via Emergent, configure EXPO_PUBLIC_ENABLE_EMERGENT_AUTH=true. Para Apple, configure EXPO_PUBLIC_ENABLE_APPLE_AUTH=true, habilite a capacidade na conta Apple Developer e preencha APPLE_CLIENT_ID, APPLE_TEAM_ID, APPLE_KEY_ID e APPLE_PRIVATE_KEY no backend. O módulo e o plugin nativo Apple já estão incluídos. Reinicie o Expo após alterar essas opções.

Contas por senha não são vinculadas automaticamente a provedores sociais por coincidência de e-mail. Recuperação e verificação de e-mail por SMTP não estão implementadas nesta versão; planeje esse serviço antes de abrir cadastro público.

## Testes e diagnósticos

Frontend:
```powershell
cd frontend
npm run typecheck
npm run lint
npx expo export --platform all
```

Backend, sem banco ou serviços externos:
```powershell
cd backend
.\.venv\Scripts\python.exe -m pytest -n 0 tests/test_taco_data.py tests/test_workouts_lib.py tests/test_apple_auth.py tests/test_runtime_api.py tests/test_password_auth.py tests/test_ai_direct.py
```

Para testes das rotas, inicie o backend com um banco terminado em _test, configure EXPO_PUBLIC_BACKEND_URL para esse servidor e execute seed_test.py com ALLOW_TEST_SEED=1 e o mesmo DB_NAME/MONGO_URL. O seed cria contas com tokens públicos e só aceita banco de testes. Rode os testes de API em série (`-n 0`) para evitar interferência entre os casos que modificam o perfil.

/health verifica o processo. /ready confirma conexão com o banco. Os detalhes das validações e os alertas restantes estão em REVISAO.md.

## Estrutura

- backend/: API, autenticação, cliente de IA, TACO, biblioteca de exercícios e testes.
- frontend/: telas Expo Router, tema, componentes e acesso à API.
- docs/: política de privacidade e checklist das lojas.
- compose.yaml: preparação do ambiente com MongoDB, API e frontend web.
- frontend/eas.json: perfis de preparação para APK interno e builds de produção; assinatura depende da conta Expo/lojas.

Antes de publicar, preencha PRIVACY_CONTACT em frontend/src/constants.ts e gere a política com `python docs/build_privacy_html.py`. Ela precisa de revisão e de endereço público. Consulte docs/lojas-checklist.md.
