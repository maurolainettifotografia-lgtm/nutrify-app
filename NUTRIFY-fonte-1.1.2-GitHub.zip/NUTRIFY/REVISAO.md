# Nutrify — execução independente e validação das pendências

Revisão de 23/10/2026. Esta versão substitui a entrega anterior. O app pode ser executado localmente sem a plataforma Emergent. Não foi publicado em servidor público ou nas lojas.

## Resolvido e validado

- MongoDB Community 8.0.26 real, isolado em banco nutrify_validation_test: backend iniciou e criou os índices, incluindo o índice parcial Apple. Não foi usado banco de produção.
- 43 testes de API passaram com o MongoDB real: perfil, metas, diário, água, peso, relatórios, receitas, favoritos, exercícios, rotinas, sessões de treino, privacidade, exportação, cadastro, login, limite de tentativas, logout e exclusão da conta. Três testes dependentes de IA/produto externo foram excluídos dessa execução.
- 33 testes locais passaram: TACO, cálculos de treino, verificação criptográfica Apple, regressões de configuração, proteção de senhas e transporte de IA. Total das duas execuções: 76 testes aprovados.
- Interface web: login com conta fictícia, navegação ao painel e carregamento de metas do MongoDB real confirmados no navegador. Captura do painel entregue junto ao projeto.
- TypeScript e ESLint passaram. Bundles web, Android e iOS foram gerados. Não foi gerado APK/IPA assinado nem feito teste de câmera em aparelho.
- FastAPI, Starlette e Uvicorn atualizados; versões Python utilizadas nos testes foram fixadas em requirements.txt. O TestClient ainda emite aviso de descontinuação sobre httpx; isso não causou falha nos testes.
- Cadastro e login próprios por e-mail/senha, sem Emergent. Derivação de senha PBKDF2-HMAC-SHA256, salt aleatório e 600 mil iterações; comparação em tempo constante e trabalho de derivação fora do event loop. Limites de tentativas persistidos no MongoDB, por e-mail e IP, com expiração.
- Não há vinculação automática de contas por senha a provedores sociais apenas por coincidência de e-mail. Hash de senha não aparece nas respostas ou exportações. Logout e exclusão invalidam os tokens.
- A interface agora mostra os erros do login local. Sessões expiradas limpam o cache e retornam ao fluxo de entrada.
- Cliente direto da OpenAI para foto, sugestões e chat em streaming. Testes HTTP simulados validaram payload de imagem, histórico, resposta e streaming. Chaves ficam no backend; não houve chamada paga ou envio de dados pessoais à IA.
- Login Google/Emergent e Apple agora são opcionais na interface; e-mail/senha é o padrão.
- Corrigido cache do Metro que reutilizava endereço antigo da API. A configuração pública passa a separar o cache. Web também suporta mesma origem por proxy; no celular a URL continua configurável.
- /ready verifica o MongoDB. /health continua verificando o processo.
- Preparados Dockerfiles, compose.yaml com persistência/autenticação do MongoDB, Nginx e perfis EAS para APK de teste e produção. Arquivos revisados, mas Docker e EAS não foram executados nesta máquina.
- README e política de privacidade atualizados para o login próprio e a IA direta. O contato real do responsável continua pendente.

## Dependências: cinco alertas corrigidos, 18 ainda abertos

A atualização do ESLint e a substituição transitiva de decode-uri-component reduziram o npm audit de 23 para 18 alertas, todos altos. A resolução do npm foi fixada em package-lock.json; overrides contém a correção transitiva. As antigas resolutions exclusivas de Yarn foram removidas para evitar falsa impressão de proteção ao instalar com npm.

Os 18 avisos restantes se propagam na árvore a partir de duas bibliotecas:

- braces 3.0.3: GHSA-vfj7-8cjw-p6xm, exaustão de pilha em padrões profundamente aninhados. A versão mais recente consultada no npm ainda era 3.0.3.
- node-forge 1.4.0: GHSA-86w9-cpqp-85rv, verificação de assinaturas RSA. A versão mais recente consultada ainda era 1.4.0.

A contagem de 18 não significa 18 falhas independentes no código do Nutrify; inclui os pacotes que dependem dessas bibliotecas. Também não significa que esses avisos sejam inofensivos. Não foram ocultados, não foram aplicados downgrades incompatíveis e a validação local não prova ausência de exploração. Reavaliar as correções publicadas e a exposição de cada caminho antes de lançamento público.

Fontes dos avisos: https://github.com/advisories/GHSA-vfj7-8cjw-p6xm e https://github.com/advisories/GHSA-86w9-cpqp-85rv.

## O que ainda depende de você ou de outro ambiente

1. IA real: OPENAI_API_KEY e OPENAI_MODEL de uma conta com acesso e créditos. O app funciona sem IA; a integração retorna indisponível até configurar. Não envie chaves no chat: preencha o backend/.env local ou o gerenciador de segredos da hospedagem.
2. Uso público: escolher hospedagem, domínio, HTTPS e e-mail de privacidade/suporte; configurar backup e política de retenção. Docker está preparado, mas requer instalação e teste no destino.
3. E-mail de conta: recuperação de senha e verificação por SMTP não estão implementadas. O cadastro e login locais funcionam; esse serviço precisa ser definido antes de abrir o cadastro ao público.
4. Lojas: contas Apple/Google/Expo, assinatura dos builds, identificadores e testes em aparelho para câmera, scanner, teclado, permissões e login Apple opcional.
5. Alertas de dependências: os 18 acima permanecem abertos. Esta entrega não declara o app pronto para publicação em produção.

## Como usar esta entrega

Extraia o ZIP e siga README.md. Para Windows: Python 3.12, Node.js 22.18+ com npm e MongoDB. Para Docker: preencha o .env da raiz a partir do exemplo e execute docker compose up --build -d. Não use as contas ou tokens fixos de seed em produção.

O ZIP contém código, testes, templates de configuração e instruções. Não inclui chaves, .env reais, contas locais de teste, arquivos de banco, node_modules ou o executável MongoDB baixado para validação.

Referências técnicas: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html ; https://developers.openai.com/api/reference/resources/chat ; https://developers.openai.com/api/docs/guides/images-vision?api-mode=chat ; https://www.mongodb.com/docs/v8.0/tutorial/install-mongodb-on-windows-zip/.
