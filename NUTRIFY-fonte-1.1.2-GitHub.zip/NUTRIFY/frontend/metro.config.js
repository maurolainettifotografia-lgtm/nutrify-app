const { getDefaultConfig } = require('expo/metro-config');
const config = getDefaultConfig(__dirname);
config.maxWorkers = 2;
// Separa transformações por configuração pública: trocar a API não reutiliza o bundle antigo.
config.cacheVersion = JSON.stringify(Object.fromEntries(
  Object.entries(process.env).filter(([key]) => key.startsWith('EXPO_PUBLIC_')).sort(),
));
module.exports = config;
