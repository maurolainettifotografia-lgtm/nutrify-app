# Nutrify: checklist para publicar na App Store e no Google Play

Este guia separa o que **já está pronto no código** do que **só você pode fazer** (contas, links e formulários das lojas).
As regras das lojas mudam: confira os textos atuais de cada loja antes de enviar.

## 1. Já está no código

- **Entrar com Apple** ao lado do login com Google (regra 4.8 da App Store). O servidor confere o token da Apple e, ao excluir a conta, revoga o acesso na Apple (regra 5.1.1(v)).
- **Excluir conta dentro do app** (Perfil > Excluir minha conta e dados), exigido pelas duas lojas.
- **Política de Privacidade** dentro do app, com a versão pública em `docs/privacidade.html`.
- **Consentimento antes da IA** (foto, sugestões e chat), registrado no servidor, e consentimento dos dados de saúde no cadastro.
- **Idade mínima de 18 anos**, avisos de saúde e piso de calorias.
- **Textos de permissão** da câmera e da galeria em português (`app.json`).
- **Identificadores do app:** `com.maurolainetti.nutrify` (iOS e Android), `buildNumber` 1 e `versionCode` 1. Aumente esses números a cada nova versão enviada.

## 2. O que só você pode fazer

### Contas
- Apple Developer Program (pago, renovação anual) e Google Play Console (taxa única).

### Entrar com Apple (iOS)
1. No Apple Developer, em Identifiers, abra o App ID `com.maurolainetti.nutrify` e ative a capacidade **Sign in with Apple**.
2. Em Keys, crie uma chave com **Sign in with Apple** e baixe o arquivo `.p8` (só dá para baixar uma vez). Anote o **Key ID** e o **Team ID**.
3. No `.env` do backend, adicione:
   ```
   APPLE_CLIENT_ID=com.maurolainetti.nutrify
   APPLE_TEAM_ID=<seu Team ID>
   APPLE_KEY_ID=<seu Key ID>
   APPLE_PRIVATE_KEY=<conteúdo do .p8, com \n no lugar das quebras de linha>
   ```
   As três últimas servem para revogar o acesso na exclusão da conta. Sem elas o login funciona, mas a revogação não acontece.
4. O módulo e o plugin Apple já estão incluídos. Configure `EXPO_PUBLIC_ENABLE_APPLE_AUTH=true` no frontend após configurar a conta Apple.
5. Gere o build com `eas build -p ios` e teste em um **iPhone de verdade**. Para testar no Expo Go, acrescente `host.exp.Exponent` em `APPLE_CLIENT_ID`, separado por vírgula.

### Link público da política (obrigatório nas duas lojas)
1. Preencha o e-mail em `frontend/src/constants.ts` (`PRIVACY_CONTACT`).
2. Rode `python docs/build_privacy_html.py` (ou passe `--contact seu@email`).
3. Publique `docs/privacidade.html` em um endereço público (GitHub Pages, Netlify ou seu site).
4. Use esse link no campo de política de privacidade da App Store e do Google Play. No Google Play, use o mesmo link no campo "como excluir dados" (a seção 7 da política explica isso).

### Servidor
- O backend precisa responder por **HTTPS**. Sem isso o app não passa na App Store e o formulário do Google não pode marcar "dados criptografados em trânsito".
- Defina `CORS_ORIGINS` e não rode o `seed_test.py` no banco real.

### Revisão jurídica
- Peça a um advogado para revisar a política, principalmente o prazo de 30 dias para exclusão por e-mail (seção 7), que é um compromisso seu.

## 3. Respostas para os formulários de privacidade

Baseadas no que o app faz hoje. Confira as definições de cada formulário antes de responder.

### App Store (App Privacy)
Todos os dados abaixo são coletados, **vinculados à identidade** da pessoa, para **funcionalidade do app**, e **não usados para rastreamento**:
- Informações de contato: nome, e-mail.
- Saúde e fitness: peso, altura, alimentação (saúde) e treinos (fitness).
- Conteúdo do usuário: fotos (reconhecimento de alimentos) e mensagens do chat com a IA.
- Identificadores: ID de usuário.

### Google Play (Data safety)
- **Coletados:** informações pessoais (nome, e-mail, ID de usuário); saúde e condicionamento físico; fotos; mensagens no app.
- **Compartilhamento:** os dados vão a provedores de IA somente nos recursos opcionais, após o aceite. Provedores que tratam os dados em seu nome costumam se enquadrar como "prestadores de serviço" no formulário, o que não conta como compartilhamento, mas confirme a definição atual.
- **Criptografia em trânsito:** sim (desde que o servidor use HTTPS).
- **Exclusão de dados:** sim, dentro do app e por e-mail (informe o link da política).

## 4. Cuidados na revisão das lojas

- **Conta de teste para o revisor.** O app oferece cadastro por e-mail e senha. Crie uma conta exclusiva para revisão e forneça suas credenciais nos campos seguros de acesso do revisor. Logins Google e Apple são opcionais nesta versão.
- **Saúde:** mantenha o tom de estimativa, sem prometer resultados nem tratamento. Os avisos já existem no app.
- **IA:** a Apple exige deixar claro e pedir permissão antes de enviar dados pessoais a IA de terceiros (regra 5.1.2). O consentimento do app cobre isso, e os provedores estão citados na política.
- **Classificação etária:** responda o questionário de cada loja com a realidade do app (conteúdo sobre saúde e nutrição, sem conteúdo adulto).
- **Google Play:** declare o público-alvo como adultos, preencha a declaração de apps de saúde e confira se contas pessoais novas ainda precisam de um período de teste fechado com testadores antes da produção.

## 5. Material de divulgação (você prepara)

Nome, descrição curta e longa, categoria (Saúde e fitness), ícone 1024×1024, capturas de tela de cada tamanho exigido, e-mail de suporte e site.
