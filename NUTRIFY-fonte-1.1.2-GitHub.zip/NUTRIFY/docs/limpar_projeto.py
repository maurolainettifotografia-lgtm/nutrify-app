"""Limpeza do projeto (segura): por padrao so MOSTRA o que faria. Para aplicar, use --aplicar.

    python docs/limpar_projeto.py            # mostra
    python docs/limpar_projeto.py --aplicar  # faz

O que faz:
1. Apaga copias soltas na RAIZ do projeto (de uma extracao em pasta errada), mas so se forem
   IDENTICAS as que ficam dentro de backend/. Nada diferente e apagado.
2. Se o projeto for um repositorio Git: tira do controle de versao (sem apagar do computador) os arquivos
   internos da plataforma. Ele NAO faz commit: depois rode `git commit` e `git push` por conta propria.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APPLY = "--aplicar" in sys.argv

# (copia solta na raiz, arquivo correto em backend/)
DUPLICATES = [
    ("taco_foods.py", "backend/taco_foods.py"),
    ("taco_data.json", "backend/taco_data.json"),
    ("scripts/extract_taco.py", "backend/scripts/extract_taco.py"),
    ("tests/test_taco_data.py", "backend/tests/test_taco_data.py"),
    ("tests/test_new_features.py", "backend/tests/test_new_features.py"),
]
INTERNAL = [".emergent", ".gitconfig", "TEMPLATE.md", "image_testing.md", "test_result.md", "test_reports"]


def say(msg):
    print(("[FEITO] " if APPLY else "[SIMULACAO] ") + msg)


def main():
    print("Aplicando mudancas" if APPLY else "Modo simulacao: nada sera alterado (use --aplicar para executar)")
    print()
    for stray, good in DUPLICATES:
        a, b = ROOT / stray, ROOT / good
        if not a.exists():
            continue
        if not b.exists() or a.read_bytes() != b.read_bytes():
            print(f"[PULADO] {stray}: nao e copia identica de {good}, entao foi mantido")
            continue
        say(f"apagar copia solta {stray}")
        if APPLY:
            a.unlink()
            parent = a.parent
            if parent != ROOT and not any(parent.iterdir()):
                parent.rmdir()

    if (ROOT / ".git").exists():
        for path in INTERNAL:
            tracked = subprocess.run(["git", "ls-files", "--", path], cwd=ROOT, capture_output=True, text=True).stdout.strip()
            if not tracked:
                continue
            say(f"tirar do Git (o arquivo continua no seu computador): {path}")
            if APPLY:
                subprocess.run(["git", "rm", "-r", "--cached", "-q", "--", path], cwd=ROOT, check=True)
        if APPLY:
            print('\nPronto. Agora envie com:  git add .  &&  git commit -m "Limpeza do projeto"  &&  git push')
    else:
        print("[INFO] Esta pasta nao e um repositorio Git: pulei a parte do Git.")


if __name__ == "__main__":
    main()
