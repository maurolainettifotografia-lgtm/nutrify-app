"""Gera docs/privacidade.html (pagina PUBLICA da Politica de Privacidade) a partir do mesmo texto do app.

As lojas (App Store e Google Play) exigem um LINK publico para a politica de privacidade, e o Google Play
tambem pede um link para "como excluir a conta/dados" (a secao 7 da politica cobre isso).

Uso:
    python docs/build_privacy_html.py                      # usa o e-mail definido em frontend/src/constants.ts
    python docs/build_privacy_html.py --contact voce@exemplo.com.br
Depois publique o arquivo gerado (GitHub Pages, Netlify, seu site...) e use o link nas lojas.
"""
import argparse
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONSTANTS = (ROOT / "frontend/src/constants.ts").read_text(encoding="utf-8")
CONTENT = json.loads((ROOT / "frontend/src/privacy-content.json").read_text(encoding="utf-8"))


def const(name: str) -> str:
    return re.search(rf'export const {name} = "(.*?)";', CONSTANTS).group(1)


def render(contact: str, version: str) -> str:
    parts = []
    for s in CONTENT["sections"]:
        parts.append(f"<h2>{html.escape(s['title'])}</h2>")
        bullets = []
        for line in s["body"] + [None]:
            if line is not None and line.startswith("• "):
                bullets.append(line[2:])
                continue
            if bullets:
                parts.append("<ul>" + "".join(f"<li>{html.escape(b).replace('{{CONTATO}}', html.escape(contact))}</li>" for b in bullets) + "</ul>")
                bullets = []
            if line is not None:
                parts.append(f"<p>{html.escape(line).replace('{{CONTATO}}', html.escape(contact))}</p>")
    body = "\n".join(parts)
    return f"""<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Política de Privacidade - Nutrify</title>
<style>
  :root {{ color-scheme: light dark; --fg:#1b1d21; --bg:#ffffff; --muted:#5b616b; --line:#e3e5e8; }}
  @media (prefers-color-scheme: dark) {{ :root {{ --fg:#eceef1; --bg:#0d0f12; --muted:#a3a9b3; --line:#2a2e35; }} }}
  body {{ margin:0; background:var(--bg); color:var(--fg); font:16px/1.65 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }}
  main {{ max-width:760px; margin:0 auto; padding:32px 20px 64px; }}
  h1 {{ font-size:28px; margin:0 0 4px; }} h2 {{ font-size:19px; margin:32px 0 8px; }}
  .v {{ color:var(--muted); font-size:14px; margin-bottom:24px; }}
  ul {{ padding-left:20px; }} li {{ margin:6px 0; }}
</style>
</head>
<body>
<main>
<h1>Política de Privacidade do Nutrify</h1>
<div class="v">Versão {html.escape(version)}</div>
{body}
</main>
</body>
</html>
"""


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--contact", default=const("PRIVACY_CONTACT"))
    args = ap.parse_args()
    out = Path(__file__).with_name("privacidade.html")
    out.write_text(render(args.contact, const("POLICY_VERSION")), encoding="utf-8")
    print(f"Gerado: {out}")
    if args.contact.startswith("[PREENCHER"):
        print("ATENCAO: o e-mail de contato ainda nao foi preenchido (use --contact ou edite constants.ts).")
