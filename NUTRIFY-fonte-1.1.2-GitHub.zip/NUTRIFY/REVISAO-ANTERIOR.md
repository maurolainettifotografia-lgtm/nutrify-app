# Revisão do Nutrify — 23/10/2026

## Resultado
O projeto tinha problemas de instalação e configuração. A versão entregue contém as correções descritas abaixo, passou nas verificações locais e gerou os bundles de web, Android e iOS. Não é possível afirmar que todos os fluxos em produção funcionam sem testar com MongoDB real, contas e credenciais dos serviços externos.

## Alterações
- Incluídos expo-apple-authentication e seu plugin de configuração, na versão indicada pelo SDK Expo instalado.
- Corrigido o preinstall para executar com Node no Windows.
- Criado package-lock.json para instalação reproduzível com npm ci e adicionado npm run typecheck.
- Adicionados backend/.env.example e frontend/.env.example, com instruções para Windows, celular e emulador no README.
- Normalizado o endereço da API, removendo barras finais; ausência de configuração produz mensagem explícita em vez de requisições para undefined/api.
- Limpeza do cache do React Query ao entrar/sair de uma conta, para reduzir o risco de exibir dados de outra sessão.
- Permissão de nova tentativa após falha na troca do session_id e tratamento de erro na inicialização da autenticação, evitando carregamento permanente.
- Estabilizado o contexto de notificações, evitando recarregamentos do chat provocados por alterações do toast.
- Corrigido acesso a ref durante renderização do treino; escolha de métrica do gráfico passou a ser derivada dos dados.
- Ajustados problemas de lint, incluindo aspas em JSX; exceções locais documentadas para sincronização de formulários e callback de envio.
- Corrigidos testes locais que exigiam EXPO_PUBLIC_BACKEND_URL mesmo sem fazer chamadas de rede.
- Dependências Python reduzidas às utilizadas pela aplicação e testes. O SDK privado de IA foi separado em requirements-ai.txt, pois a versão informada retornou 404 no PyPI público.
- IA sem chave/SDK retorna HTTP 503; falta de consentimento mantém prioridade e retorna 403. Não consome quota quando a integração está indisponível.
- Ausência de MONGO_URL/DB_NAME agora produz orientação de configuração.
- Adicionados sete testes de regressão para saúde, autenticação e indisponibilidade/consentimento da IA.

## Validação executada
- TypeScript: tsc --noEmit, aprovado.
- ESLint: aprovado, sem erros ou avisos na verificação final.
- Hook preinstall: aprovado.
- Expo export --platform all: concluído; bundles web, Android e iOS, incluindo bytecode Hermes nativo.
- Backend: 28 testes passaram (TACO, biblioteca de treinos, Apple e novas regressões de configuração).
- Mais 27 testes existentes de água, receitas, treinos e privacidade passaram com FastAPI TestClient e MongoDB simulado em memória. A criação de índices foi desativada somente nessa simulação porque o simulador não implementa corretamente o índice parcial apple_sub. O código de índices da aplicação permanece preservado.
- A suíte Python emitiu aviso de descontinuação de uma API do AnyIO usada pelo TestClient antigo.

## Pendências para execução completa
1. Configure os arquivos .env e mantenha o MongoDB em execução. O banco real e seus índices não foram validados nesta revisão.
2. Configure Emergent Auth para login Google e Apple Developer para login Apple. Nenhum login real foi executado.
3. Para a IA, obtenha o índice oficial de pacotes da plataforma Emergent, instale requirements-ai.txt e configure EMERGENT_LLM_KEY. Sem isso, foto, sugestões e chat ficam indisponíveis; a API principal não depende dessa instalação.
4. O npm audit encontrou 23 alertas na árvore de dependências (2 baixos, 3 moderados, 18 altos). Eles ainda precisam de triagem antes de publicar. Não foi aplicado audit fix --force: algumas sugestões faziam downgrade do Expo 57 para 44 ou alteravam a versão principal de bibliotecas nativas. As resolutions existentes são específicas de Yarn e não substituem correções verificadas com npm.
5. A geração de bundles não equivale a um APK/IPA assinado ou teste em aparelho. Câmera, scanner, permissões, retorno de login e interface precisam de teste no dispositivo e no navegador com o backend configurado.
6. Configure PRIVACY_CONTACT, URLs públicas e os itens de docs/lojas-checklist.md antes de enviar às lojas.

## Como começar
Extraia NUTRIFY-corrigido.zip e siga a seção “Configuração local no Windows” do README.md. Use npm ci no frontend. O ZIP não contém node_modules, banco, credenciais ou caches gerados durante a revisão.
